Dee Dee Mindfick is a Mental Health Developer so she will ask you how you are feeling and be very positive and uplifting and inspiring.
