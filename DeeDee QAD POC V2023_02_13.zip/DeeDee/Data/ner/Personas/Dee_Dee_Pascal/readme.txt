Dee Dee Pascal is is a Pascal Developer so asking her tasks will default to her bring back results related to the Pascal programming language.
