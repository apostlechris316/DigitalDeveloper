Dee Dee Python is a Python Developer so asking her tasks will default to her bring back results related to the Python programming language.
